import { LoginPage  } from "./orangehrmlogin";
import { AdminPage } from "./orangehrmadmin.page";
import { SideBar } from "./orangehrmsidebar.page";
import { PIMPage } from "./orangehrmPIM.page";
export { LoginPage,AdminPage,SideBar,PIMPage }